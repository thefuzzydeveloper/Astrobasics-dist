import { _ as U, __tla as __tla_0 } from "./index-BxR0Moj8.js";
import "./react-cxkclgJA.js";
let J, Y, g, B, b, G, O, j, I, T, V, f, D, q, $, X, k, Z, z, x, L, N, H, v, y, C;
let __tla = Promise.all([
    (()=>{
        try {
            return __tla_0;
        } catch  {}
    })()
]).then(async ()=>{
    let S, _, E, A, d, l, w;
    S = Object.defineProperty;
    _ = (r, t)=>S(r, "name", {
            value: t,
            configurable: !0
        });
    b = ((r)=>(r[r.Julian = 0] = "Julian", r[r.Gregorian = 1] = "Gregorian", r))(b || {});
    k = ((r)=>(r[r.Sun = 0] = "Sun", r[r.Moon = 1] = "Moon", r[r.Mercury = 2] = "Mercury", r[r.Venus = 3] = "Venus", r[r.Mars = 4] = "Mars", r[r.Jupiter = 5] = "Jupiter", r[r.Saturn = 6] = "Saturn", r[r.Uranus = 7] = "Uranus", r[r.Neptune = 8] = "Neptune", r[r.Pluto = 9] = "Pluto", r[r.Earth = 14] = "Earth", r[r.EclipticNutation = -1] = "EclipticNutation", r[r.FixedStar = -10] = "FixedStar", r))(k || {});
    $ = ((r)=>(r[r.MeanNode = 10] = "MeanNode", r[r.TrueNode = 11] = "TrueNode", r[r.MeanApogee = 12] = "MeanApogee", r[r.OsculatingApogee = 13] = "OsculatingApogee", r[r.InterpolatedApogee = 21] = "InterpolatedApogee", r[r.InterpolatedPerigee = 22] = "InterpolatedPerigee", r))($ || {});
    J = ((r)=>(r[r.Chiron = 15] = "Chiron", r[r.Pholus = 16] = "Pholus", r[r.Ceres = 17] = "Ceres", r[r.Pallas = 18] = "Pallas", r[r.Juno = 19] = "Juno", r[r.Vesta = 20] = "Vesta", r))(J || {});
    V = ((r)=>(r[r.Cupido = 40] = "Cupido", r[r.Hades = 41] = "Hades", r[r.Zeus = 42] = "Zeus", r[r.Kronos = 43] = "Kronos", r[r.Apollon = 44] = "Apollon", r[r.Admetos = 45] = "Admetos", r[r.Vulkanus = 46] = "Vulkanus", r[r.Poseidon = 47] = "Poseidon", r[r.Isis = 48] = "Isis", r[r.Nibiru = 49] = "Nibiru", r[r.Harrington = 50] = "Harrington", r[r.NeptuneLeverrier = 51] = "NeptuneLeverrier", r[r.NeptuneAdams = 52] = "NeptuneAdams", r[r.PlutoLowell = 53] = "PlutoLowell", r[r.PlutoPickering = 54] = "PlutoPickering", r[r.Vulcan = 55] = "Vulcan", r[r.WhiteMoon = 56] = "WhiteMoon", r[r.Proserpina = 57] = "Proserpina", r[r.Waldemath = 58] = "Waldemath", r))(V || {});
    D = ((r)=>(r.Placidus = "P", r.Koch = "K", r.Porphyrius = "O", r.Regiomontanus = "R", r.Campanus = "C", r.Equal = "A", r.VehlowEqual = "V", r.WholeSign = "W", r.Meridian = "X", r.Azimuthal = "H", r.PolichPage = "T", r.Alcabitus = "B", r.Morinus = "M", r))(D || {});
    f = ((r)=>(r[r.Ascendant = 0] = "Ascendant", r[r.MC = 1] = "MC", r[r.ARMC = 2] = "ARMC", r[r.Vertex = 3] = "Vertex", r[r.EquatorialAscendant = 4] = "EquatorialAscendant", r[r.CoAscendant1 = 5] = "CoAscendant1", r[r.CoAscendant2 = 6] = "CoAscendant2", r[r.PolarAscendant = 7] = "PolarAscendant", r))(f || {});
    g = ((r)=>(r[r.JPLEphemeris = 1] = "JPLEphemeris", r[r.SwissEphemeris = 2] = "SwissEphemeris", r[r.MoshierEphemeris = 4] = "MoshierEphemeris", r[r.Heliocentric = 8] = "Heliocentric", r[r.TruePositions = 16] = "TruePositions", r[r.J2000 = 32] = "J2000", r[r.NoNutation = 64] = "NoNutation", r[r.Speed3 = 128] = "Speed3", r[r.Speed = 256] = "Speed", r[r.NoGravitationalDeflection = 512] = "NoGravitationalDeflection", r[r.NoAberration = 1024] = "NoAberration", r[r.Equatorial = 2048] = "Equatorial", r[r.XYZ = 4096] = "XYZ", r[r.Radians = 8192] = "Radians", r[r.Barycentric = 16384] = "Barycentric", r[r.Topocentric = 32768] = "Topocentric", r[r.Sidereal = 65536] = "Sidereal", r[r.ICRS = 131072] = "ICRS", r[r.DpsidepsIAU1980 = 262144] = "DpsidepsIAU1980", r[r.JPLHorizons = 524288] = "JPLHorizons", r[r.JPLHorizonsApprox = 1048576] = "JPLHorizonsApprox", r))(g || {});
    G = {
        Astrometric: 1536,
        DefaultSwissEphemeris: 258,
        DefaultMoshier: 260
    };
    I = ((r)=>(r[r.Central = 1] = "Central", r[r.NonCentral = 2] = "NonCentral", r[r.Total = 4] = "Total", r[r.Annular = 8] = "Annular", r[r.Partial = 16] = "Partial", r[r.AnnularTotal = 32] = "AnnularTotal", r[r.Penumbral = 64] = "Penumbral", r))(I || {});
    O = {
        AllSolar: 63,
        AllLunar: 84
    };
    x = ((r)=>(r[r.FaganBradley = 0] = "FaganBradley", r[r.Lahiri = 1] = "Lahiri", r[r.DeLuce = 2] = "DeLuce", r[r.Raman = 3] = "Raman", r[r.Ushashashi = 4] = "Ushashashi", r[r.Krishnamurti = 5] = "Krishnamurti", r[r.DjwhalKhul = 6] = "DjwhalKhul", r[r.Yukteshwar = 7] = "Yukteshwar", r[r.JNBhasin = 8] = "JNBhasin", r[r.BabylKugler1 = 9] = "BabylKugler1", r[r.BabylKugler2 = 10] = "BabylKugler2", r[r.BabylKugler3 = 11] = "BabylKugler3", r[r.BabylHuber = 12] = "BabylHuber", r[r.BabylEtPSC = 13] = "BabylEtPSC", r[r.Aldebaran15Tau = 14] = "Aldebaran15Tau", r[r.Hipparchos = 15] = "Hipparchos", r[r.Sassanian = 16] = "Sassanian", r[r.GalacticCenter0Sag = 17] = "GalacticCenter0Sag", r[r.J2000 = 18] = "J2000", r[r.J1900 = 19] = "J1900", r[r.B1950 = 20] = "B1950", r[r.SuryaSiddhanta = 21] = "SuryaSiddhanta", r[r.SuryaSiddhantaMeanSun = 22] = "SuryaSiddhantaMeanSun", r[r.Aryabhata = 23] = "Aryabhata", r[r.AryabhataMeanSun = 24] = "AryabhataMeanSun", r[r.SSRevati = 25] = "SSRevati", r[r.SSCitra = 26] = "SSCitra", r[r.TrueCitra = 27] = "TrueCitra", r[r.TrueRevati = 28] = "TrueRevati", r[r.TruePushya = 29] = "TruePushya", r[r.GalacticCenterGilBrand = 30] = "GalacticCenterGilBrand", r[r.GalacticEquatorIAU1958 = 31] = "GalacticEquatorIAU1958", r[r.GalacticEquator = 32] = "GalacticEquator", r[r.GalacticEquatorMidMula = 33] = "GalacticEquatorMidMula", r[r.Skydram = 34] = "Skydram", r[r.TrueMula = 35] = "TrueMula", r[r.DhruvaGalCenterMulaWilhelm = 36] = "DhruvaGalCenterMulaWilhelm", r[r.Aryabhata522 = 37] = "Aryabhata522", r[r.BabylBritton = 38] = "BabylBritton", r[r.UserDefined = 255] = "UserDefined", r))(x || {});
    z = ((r)=>(r[r.Rise = 1] = "Rise", r[r.Set = 2] = "Set", r[r.UpperTransit = 4] = "UpperTransit", r[r.LowerTransit = 8] = "LowerTransit", r))(z || {});
    Y = 1e4;
    Z = 9e3;
    X = 23;
    q = (E = class {
        constructor(r, t, n, e, a, s, i, o){
            this.type = r, this.maximum = t, this.partialBegin = n, this.partialEnd = e, this.totalBegin = a, this.totalEnd = s, this.penumbralBegin = i, this.penumbralEnd = o;
        }
        isTotal() {
            return (this.type & 4) !== 0;
        }
        isPartial() {
            return (this.type & 16) !== 0;
        }
        isPenumbralOnly() {
            return (this.type & 64) !== 0 && (this.type & 20) === 0;
        }
        getTotalityDuration() {
            if (!this.isTotal() || this.totalBegin === 0 || this.totalEnd === 0) return 0;
            const r = (this.totalEnd - this.totalBegin) * 24;
            return r > 0 ? r : 0;
        }
        getPartialDuration() {
            if (this.partialBegin === 0 || this.partialEnd === 0) return 0;
            const r = (this.partialEnd - this.partialBegin) * 24;
            return r > 0 ? r : 0;
        }
        getTotalDuration() {
            if (this.penumbralBegin === 0 || this.penumbralEnd === 0) return 0;
            const r = (this.penumbralEnd - this.penumbralBegin) * 24;
            return r > 0 ? r : 0;
        }
    }, _(E, "LunarEclipseImpl"), E);
    L = (A = class {
        constructor(r, t, n, e, a, s, i, o){
            this.type = r, this.maximum = t, this.partialBegin = n, this.partialEnd = e, this.centralBegin = a, this.centralEnd = s, this.centerLineBegin = i, this.centerLineEnd = o;
        }
        isTotal() {
            return (this.type & 4) !== 0;
        }
        isAnnular() {
            return (this.type & 8) !== 0;
        }
        isHybrid() {
            return (this.type & 32) !== 0;
        }
        isPartial() {
            return (this.type & 16) !== 0;
        }
        isCentral() {
            return (this.type & 1) !== 0;
        }
        isNonCentral() {
            return (this.type & 2) !== 0;
        }
    }, _(A, "SolarEclipseImpl"), A);
    j = (d = class {
        constructor(r, t, n, e, a = 1){
            this.year = r, this.month = t, this.day = n, this.hour = e, this.calendarType = a;
        }
        toISOString() {
            const r = Math.floor(this.hour), t = Math.floor((this.hour - r) * 60), n = Math.floor(((this.hour - r) * 60 - t) * 60), e = Math.floor((((this.hour - r) * 60 - t) * 60 - n) * 1e3), a = Math.abs(this.year).toString().padStart(4, "0"), s = this.year < 0 ? "-" : "", i = this.month.toString().padStart(2, "0"), o = this.day.toString().padStart(2, "0"), m = r.toString().padStart(2, "0"), c = t.toString().padStart(2, "0"), u = n.toString().padStart(2, "0"), h = e.toString().padStart(3, "0");
            return `${s}${a}-${i}-${o}T${m}:${c}:${u}.${h}Z`;
        }
        toString() {
            const r = this.calendarType === 1 ? "Gregorian" : "Julian";
            return `${this.year < 0 ? `${Math.abs(this.year)} BCE` : this.year.toString()}-${this.month.toString().padStart(2, "0")}-${this.day.toString().padStart(2, "0")} ${this.hour.toFixed(6)} hours (${r})`;
        }
    }, _(d, "DateTimeImpl"), d);
    B = (l = class {
        constructor(r){
            this.flags = 0, r !== void 0 && this.add(r);
        }
        add(r) {
            return Array.isArray(r) ? r.forEach((t)=>this.flags |= t) : this.flags |= r, this;
        }
        remove(r) {
            return Array.isArray(r) ? r.forEach((t)=>this.flags &= ~t) : this.flags &= ~r, this;
        }
        has(r) {
            return (this.flags & r) === r;
        }
        toNumber() {
            return this.flags;
        }
        static from(...r) {
            return new l(r);
        }
        static get swissEphemerisWithSpeed() {
            return l.from(2, 256);
        }
        static get moshierWithSpeed() {
            return l.from(4, 256);
        }
        static get astrometric() {
            return l.from(2, 1024, 512);
        }
        static get heliocentric() {
            return l.from(2, 8);
        }
        static get topocentric() {
            return l.from(2, 32768);
        }
        static get equatorial() {
            return l.from(2, 2048, 256);
        }
    }, _(l, "_CalculationFlags"), l);
    T = (w = class {
        constructor(r){
            this.flags = 0, r !== void 0 && this.add(r);
        }
        add(r) {
            return Array.isArray(r) ? r.forEach((t)=>this.flags |= t) : this.flags |= r, this;
        }
        has(r) {
            return (this.flags & r) === r;
        }
        toNumber() {
            return this.flags;
        }
        static from(...r) {
            return new w(r);
        }
        static get allSolar() {
            return new w([
                1,
                2,
                4,
                8,
                16,
                32
            ]);
        }
        static get allLunar() {
            return new w([
                4,
                16,
                64
            ]);
        }
        static get totalOnly() {
            return w.from(4);
        }
        static get totalAndPartial() {
            return w.from(4, 16);
        }
    }, _(w, "_EclipseTypeFlags"), w);
    y = function(r) {
        return typeof r == "number" ? r : r instanceof B ? r.toNumber() : Array.isArray(r) ? B.from(...r).toNumber() : r;
    };
    _(y, "normalizeFlags");
    v = function(r) {
        return typeof r == "number" ? r : r instanceof T ? r.toNumber() : Array.isArray(r) ? T.from(...r).toNumber() : r;
    };
    _(v, "normalizeEclipseTypes");
    var R = class {
        constructor(){
            this.module = null, this.ready = !1;
        }
        async init(t) {
            if (this.ready) return;
            const n = await U(()=>import("./swisseph-CFv1eqPm.js"), [], import.meta.url);
            let e;
            if (typeof n.default == "function" ? e = n.default : typeof n == "function" ? e = n : n.default ? e = n.default : e = n.SwissEphModule || n, typeof e != "function") throw new Error("Failed to load WASM module: SwissEphModule factory function not found");
            let a = t;
            if (!a) try {
                a = new URL("" + new URL("swisseph-BmP0Bw24.wasm", import.meta.url).href, import.meta.url).href;
            } catch  {
                a = "swisseph.wasm";
            }
            this.module = await e({
                locateFile: _((s, i)=>s === "swisseph.wasm" ? a : i ? i + s : s, "locateFile")
            }), this._wrapFunctions(), this.ready = !0, console.log("Swiss Ephemeris WASM initialized:", this.version());
        }
        _wrapFunctions() {
            const t = this.module;
            this._julday = t.cwrap("swe_julday_wrap", "number", [
                "number",
                "number",
                "number",
                "number",
                "number"
            ]), this._getPlanetName = t.cwrap("swe_get_planet_name_wrap", "string", [
                "number"
            ]), this._setSiderealMode = t.cwrap("swe_set_sid_mode_wrap", null, [
                "number",
                "number",
                "number"
            ]), this._getAyanamsa = t.cwrap("swe_get_ayanamsa_ut_wrap", "number", [
                "number"
            ]), this._close = t.cwrap("swe_close_wrap", null, []), this._version = t.cwrap("swe_version_wrap", "string", []);
        }
        _checkReady() {
            if (!this.ready) throw new Error("SwissEphemeris not initialized. Call await swe.init() first.");
        }
        version() {
            return this._checkReady(), this._version();
        }
        setEphemerisPath(t) {
            this._checkReady();
            const n = this.module, e = n.allocateUTF8(t || "");
            n.ccall("swe_set_ephe_path_wrap", null, [
                "number"
            ], [
                e
            ]), n._free(e);
        }
        async loadStandardEphemeris() {
            const t = "https://cdn.jsdelivr.net/gh/aloistr/swisseph/ephe";
            await this.loadEphemerisFiles([
                {
                    name: "sepl_18.se1",
                    url: `${t}/sepl_18.se1`
                },
                {
                    name: "semo_18.se1",
                    url: `${t}/semo_18.se1`
                },
                {
                    name: "seas_18.se1",
                    url: `${t}/seas_18.se1`
                }
            ]);
        }
        async loadEphemerisFiles(t) {
            this._checkReady();
            const n = this.module;
            try {
                n.FS.mkdir("/ephemeris");
            } catch  {}
            for (const e of t){
                const a = await fetch(e.url);
                if (!a.ok) throw new Error(`Failed to download ${e.name}: ${a.statusText}`);
                const s = await a.arrayBuffer(), i = new Uint8Array(s);
                n.FS.writeFile(`/ephemeris/${e.name}`, i);
            }
            this.setEphemerisPath("/ephemeris");
        }
        julianDay(t, n, e, a = 0, s = b.Gregorian) {
            if (this._checkReady(), !Number.isFinite(t) || !Number.isFinite(n) || !Number.isFinite(e) || !Number.isFinite(a)) throw new TypeError(`julianDay requires finite numbers. Received: year=${t}, month=${n}, day=${e}, hour=${a}`);
            return this._julday(t, n, e, a, s);
        }
        dateToJulianDay(t, n = b.Gregorian) {
            if (this._checkReady(), !(t instanceof Date)) throw new TypeError("dateToJulianDay expects a Date object");
            const e = t.getUTCFullYear(), a = t.getUTCMonth() + 1, s = t.getUTCDate(), i = t.getUTCHours(), o = t.getUTCMinutes(), m = t.getUTCSeconds(), c = t.getUTCMilliseconds();
            if (isNaN(e) || isNaN(a) || isNaN(s) || isNaN(i)) throw new TypeError(`Invalid Date object provided to dateToJulianDay. Date.toString() returned: "${t.toString()}". Please ensure the date is valid (e.g., avoid new Date("invalid")).`);
            const u = i + o / 60 + m / 3600 + c / 36e5;
            return this.julianDay(e, a, s, u, n);
        }
        julianDayToDate(t, n = b.Gregorian) {
            this._checkReady();
            const e = this.module, a = e._malloc(4), s = e._malloc(4), i = e._malloc(4), o = e._malloc(8);
            e.ccall("swe_revjul_wrap", null, [
                "number",
                "number",
                "number",
                "number",
                "number",
                "number"
            ], [
                t,
                n,
                a,
                s,
                i,
                o
            ]);
            const m = e.getValue(a, "i32"), c = e.getValue(s, "i32"), u = e.getValue(i, "i32"), h = e.getValue(o, "double");
            return e._free(a), e._free(s), e._free(i), e._free(o), new j(m, c, u, h, n);
        }
        calculatePosition(t, n, e = G.DefaultMoshier) {
            this._checkReady();
            const a = y(e), s = this.module, i = s._malloc(6 * 8), o = s._malloc(256), m = s.ccall("swe_calc_ut_wrap", "number", [
                "number",
                "number",
                "number",
                "number",
                "number"
            ], [
                t,
                n,
                a,
                i,
                o
            ]);
            if (m < 0) {
                const u = s.UTF8ToString(o);
                throw s._free(i), s._free(o), new Error(u);
            }
            const c = [];
            for(let u = 0; u < 6; u++)c[u] = s.getValue(i + u * 8, "double");
            return s._free(i), s._free(o), {
                longitude: c[0],
                latitude: c[1],
                distance: c[2],
                longitudeSpeed: c[3],
                latitudeSpeed: c[4],
                distanceSpeed: c[5],
                flags: m
            };
        }
        getCelestialBodyName(t) {
            return this._checkReady(), this._getPlanetName(t);
        }
        setSiderealMode(t, n = 0, e = 0) {
            this._checkReady(), this._setSiderealMode(t, n, e);
        }
        getAyanamsa(t) {
            return this._checkReady(), this._getAyanamsa(t);
        }
        getAyanamsaExUt(t, n = g.SwissEphemeris) {
            this._checkReady();
            const e = y(n), a = this.module, s = a._malloc(8), i = a._malloc(256);
            try {
                if (a.ccall("swe_get_ayanamsa_ex_ut_wrap", "number", [
                    "number",
                    "number",
                    "number",
                    "number"
                ], [
                    t,
                    e,
                    s,
                    i
                ]) < 0) {
                    const m = a.UTF8ToString(i);
                    throw new Error(m || "Failed to calculate ayanamsa");
                }
                return a.getValue(s, "double");
            } finally{
                a._free(s), a._free(i);
            }
        }
        findNextLunarEclipse(t, n = g.MoshierEphemeris, e = 0, a = !1) {
            this._checkReady();
            const s = y(n), i = v(e), o = this.module, m = o._malloc(10 * 8), c = o._malloc(256), u = o.ccall("swe_lun_eclipse_when_wrap", "number", [
                "number",
                "number",
                "number",
                "number",
                "number",
                "number"
            ], [
                t,
                s,
                i,
                m,
                a ? 1 : 0,
                c
            ]);
            if (u < 0) {
                const p = o.UTF8ToString(c);
                throw o._free(m), o._free(c), new Error(p);
            }
            const h = [];
            for(let p = 0; p < 10; p++)h[p] = o.getValue(m + p * 8, "double");
            return o._free(m), o._free(c), new q(u, h[0], h[1], h[2], h[3], h[4], h[5], h[6]);
        }
        findNextSolarEclipse(t, n = g.MoshierEphemeris, e = 0, a = !1) {
            this._checkReady();
            const s = y(n), i = v(e), o = this.module, m = o._malloc(10 * 8), c = o._malloc(256), u = o.ccall("swe_sol_eclipse_when_glob_wrap", "number", [
                "number",
                "number",
                "number",
                "number",
                "number",
                "number"
            ], [
                t,
                s,
                i,
                m,
                a ? 1 : 0,
                c
            ]);
            if (u < 0) {
                const p = o.UTF8ToString(c);
                throw o._free(m), o._free(c), new Error(p);
            }
            const h = [];
            for(let p = 0; p < 10; p++)h[p] = o.getValue(m + p * 8, "double");
            return o._free(m), o._free(c), new L(u, h[0], h[1], h[2], h[3], h[4], h[5], h[6]);
        }
        calculateHouses(t, n, e, a = D.Placidus) {
            this._checkReady();
            const s = this.module, i = s._malloc(13 * 8), o = s._malloc(10 * 8), m = a.charCodeAt(0);
            s.ccall("swe_houses_wrap", "number", [
                "number",
                "number",
                "number",
                "number",
                "number",
                "number"
            ], [
                t,
                n,
                e,
                m,
                i,
                o
            ]);
            const c = [];
            for(let h = 0; h < 13; h++)c[h] = s.getValue(i + h * 8, "double");
            const u = [];
            for(let h = 0; h < 10; h++)u[h] = s.getValue(o + h * 8, "double");
            return s._free(i), s._free(o), {
                cusps: c,
                ascendant: u[f.Ascendant],
                mc: u[f.MC],
                armc: u[f.ARMC],
                vertex: u[f.Vertex],
                equatorialAscendant: u[f.EquatorialAscendant],
                coAscendant1: u[f.CoAscendant1],
                coAscendant2: u[f.CoAscendant2],
                polarAscendant: u[f.PolarAscendant],
                houseSystem: a
            };
        }
        close() {
            this.ready && this._close();
        }
    };
    _(R, "SwissEphemeris");
    N = R;
    C = new N;
    H = N;
    typeof window < "u" && (window.SwissEphemeris = N, window.swisseph = C);
});
export { J as Asteroid, Y as AsteroidOffset, g as CalculationFlag, B as CalculationFlags, b as CalendarType, G as CommonCalculationFlags, O as CommonEclipseTypes, j as DateTimeImpl, I as EclipseType, T as EclipseTypeFlags, V as FictitiousPlanet, f as HousePoint, D as HouseSystem, q as LunarEclipseImpl, $ as LunarPoint, X as NumberOfPlanets, k as Planet, Z as PlanetaryMoonOffset, z as RiseTransitFlag, x as SiderealMode, L as SolarEclipseImpl, N as SwissEphemeris, H as default, v as normalizeEclipseTypes, y as normalizeFlags, C as swisseph, __tla };
